public class  app
{
  public static void main(String args[])
  {
    myJFrame3 mjf = new myJFrame3();
  }
}
