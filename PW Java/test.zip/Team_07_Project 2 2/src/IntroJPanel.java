
import java.awt.Color;
import static java.awt.Color.BLUE;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


public class IntroJPanel extends JPanel
{
    
    //JComboBox ships, compIntel, difficulty;
    
    
    IntroJPanel ()
    {
        
       super();
       //setBackground(new Color(224, 224, 224));
       setLayout(null);
       
       
       Border thickBorder = new LineBorder(Color.BLACK, 3);
        
       JButton j12 = new JButton(); 
       j12.setText("Welcome to PSU BattleShip!!");
       add(j12);
       j12.setBorder(thickBorder);
       j12.setBounds(0,0,640,30);
       //j12.setVisible(true);
       j12.setFont(new Font("Arial", Font.PLAIN, 20));
   
       j12.setBackground(Color.BLUE); 
       j12.setForeground(Color.white);
       j12.setOpaque(true);
       
       ImageIcon imageLion = new ImageIcon("images/Nittany_Lion.gif");
       Image img = imageLion.getImage();
       Image newimg = img.getScaledInstance(320, 455,  java.awt.Image.SCALE_SMOOTH);
       imageLion = new ImageIcon(newimg);
            
            
       ImageIcon imageBattleship = new ImageIcon("images/battleship.jpg");
       Image img1 = imageBattleship.getImage();
       Image newimg1 = img1.getScaledInstance(320, 455,  java.awt.Image.SCALE_SMOOTH);
       imageBattleship = new ImageIcon(newimg1);
               
       /*      
       JButton jb1 = new JButton(); 
       add(jb1);
       jb1.setBounds(0,20,320,455);
       jb1.setIcon(imageLion);
       jb1.setBorderPainted(true);
       
                
       JButton jb2 = new JButton();
       add(jb2);
       jb2.setBounds(320,20,320,455);
       jb2.setIcon(imageBattleship);
       jb2.setBorderPainted(true);
       */
       
       JLabel backgroundship = new JLabel (imageBattleship);
       //backgroundship.setLayout(null);
       backgroundship.setBounds(320,20, 320, 455);
       //backgroundship.setOpaque(false);
       add(backgroundship);
       
       JLabel backgroundpsu = new JLabel (imageLion);
       backgroundpsu.setBounds(0,20, 320, 455);
       //backgroundpsu.setOpaque(false);
       add(backgroundpsu);
       

       
       
       String shipsList[] = {"# of Ships", "2", "3", "4", "5"};
       String compIntelList[] = {"Comp. Inteliligence", "Easy", "Normal"};
       String difficultyList [] = {"Difficulty", "Easy", "Medium", "Hard"};
       
    
       
       JComboBox ships = new JComboBox(shipsList);
       ships.setBounds(330, 150, 150, 25);  
       //ships.setSize(150, 25);
       ships.setOpaque(true);
       //ships.setContentAreaFilled(false);
       //ships.setBorderPainted(false); 
       
       
     
       JComboBox compIntel = new JComboBox(compIntelList);
       compIntel.setBounds(380, 200, 150, 25);
       //compIntel.setSize(150, 25);
       compIntel.setOpaque(true);
       
       
       JComboBox difficulty = new JComboBox(difficultyList);
       difficulty.setBounds(380, 300, 150, 25);
       //difficulty.setSize(150, 25);
       difficulty.setOpaque(true);
       
       
       add(ships); 
       add(compIntel);
       add(difficulty);
    }
       
}
