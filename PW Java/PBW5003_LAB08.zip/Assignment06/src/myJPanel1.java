import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class myJPanel1 extends JPanel implements ChangeListener, ActionListener
{
	
        JButton b2,jb2,b1,jb3;
        JTextField tft1, tft2, tft3;
        JSlider js1; 
        myJPanel2 mjp2;
        student st2;
        
        static final int FPS_MIN = 0;
        static final int FPS_MAX = 100;
        static final int FPS_INIT = 25; 

	public myJPanel1(myJPanel2 panel)
	{
            super();
                mjp2 = panel; 

		setBackground(Color.yellow);
                tft1 = new JTextField(10);
                tft1.addActionListener(this); 
		add(tft1); 
                
                tft2 = new JTextField(10);
                tft2.addActionListener(this); 
		add(tft2); 

                jb2 = mjp2.b2;               
                st2 = mjp2.st1; 
                jb3 = mjp2.b3; 
                js1 = new JSlider(JSlider.HORIZONTAL, FPS_MIN,FPS_MAX,FPS_INIT);
                
                js1.setMajorTickSpacing(25);
                js1.setMinorTickSpacing(1);
                js1.setPaintTicks(true);
                js1.setPaintLabels(true);       
                add(js1); 
                
                tft3 = new JTextField(10); 
                add(tft3);
                
                js1.addChangeListener(this);    
                b1 = new JButton("OK");
                b1.addActionListener(this); 
                add(b1); 

		}
   
    public void actionPerformed(ActionEvent event) 
    {
       	 Object obj = event.getSource();       
//=====================================
         
         ImageIcon p1 = new ImageIcon("images/Trump.jpg");
         
     	 if (obj == b1){
              st2.firstName = tft1.getText();
              st2.lastName = tft2.getText(); 
              jb2.setText(st2.firstName+ " "+ st2.lastName + " " + js1.getValue() ); 
              if (tft2.getText().equals("Trump")) {
                  jb3.setIcon(p1);
              }    
         }

    }
    
    public void stateChanged(ChangeEvent e){
        Object obj = e.getSource();  
        if (obj==js1){
            int count = js1.getValue(); 
            tft3.setText(Integer.toString(count)); 

    }

}
}