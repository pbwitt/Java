import java.awt.*;
import javax.swing.*;



public class DesignerJPanel extends JPanel
{
        JTextArea textArea;
        
        DesignerJPanel()
        {
        super();
        setBackground(new Color(224, 224, 224));
        setLayout(null);    
        
        
        textArea = new JTextArea(50,100);
        add(textArea);
        textArea.setFont(new Font("Serif", Font.BOLD, 24));
        textArea.append("Paul Witt\nKevin Hertzog \nMatt Pastor");
        textArea.setEditable(false);
        textArea.setBounds(0,0,640,480);
        }
}
