import java.awt.*;
import javax.swing.*;

public class myJButton extends JButton
{
	public myJButton(String text)
	{
		super(text);
		setBackground(Color.red);
		setOpaque(true);
	}
}