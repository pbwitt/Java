public class  app
{
  public static void main(String args[])
  {
  	
    myJFrame mjf = new myJFrame();

  }
}
