import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class myJPanel1 extends JPanel  
{
	JButton b1;
	public myJPanel1()
	{
		super();
		setBackground(Color.yellow);
		b1 = new JButton("student info will be here later ...");
		add(b1);
		}
		
}