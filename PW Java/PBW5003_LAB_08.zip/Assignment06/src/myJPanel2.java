import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class myJPanel2 extends JPanel 
{
	JButton b2, b3,b5; 
	student st1;
        myJPanel1 mjp1;

	public myJPanel2()
	{
		super();	
                st1 = new student();
		setBackground(Color.white);
		b2 = new JButton( );
		add(b2);
                b3 = new JButton(); 
                add(b3); 
           
               
                
  
                }
        
}

	
