import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class myJFrame4 extends JFrame
{
	myJPanel1 mjp1;
        JPanel aPanel;
        JLabel aLabel;
	public myJFrame4 ()
	{
		super ("My First Frame");
        //------------------------------------------------------
        // Create components: Jpanel, JLabel and JTextField
                aPanel = new JPanel();
                aLabel = new JLabel("This is a test of the emergency system");
                aPanel.add(aLabel);
                mjp1 = new myJPanel1(aPanel);  // Sharing info through constructor.
        //------------------------------------------------------
        // Choose a Layout for JFrame and 
        // add Jpanel to JFrame according to layout    	
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(mjp1, "Center");
                getContentPane().add(aPanel, "South");
        //------------------------------------------------------
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize (550, 400);
		setVisible(true);
	}
//-------------------------------------------------------------------
}
