import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class myJPanel1 extends JPanel implements ActionListener
{
	myJButton p1,p2,p3,p4;
	JLabel p5,p6;
        JPanel inPanel; 
	public myJPanel1(JPanel inP)
	{
            // Handle input parameter
                inPanel = inP;
                inPanel.setBackground(Color.yellow);
		setLayout(new GridLayout(3,2));
            //=====================================
		p1 = new myJButton("We");
                p1.addActionListener(this); 
		add(p1);
            //=====================================
		p2 = new myJButton("are");
                p2.addActionListener(this); 
		add(p2);
            //=====================================
		p3 = new myJButton("Penn");
                p3.addActionListener(this); 
		add(p3);
            //=====================================
		p4 = new myJButton("State");
                p4.addActionListener(this); 
		add(p4);
            //=====================================
                ImageIcon imagePSU = new ImageIcon("images/psu.jpg");
		p5 = new JLabel(imagePSU);
		add(p5);
            //=====================================
		p6 = new JLabel(".......");
		add(p6);
	}
//=====================================
    public void actionPerformed(ActionEvent event) 
    {
       	 Object obj = event.getSource();
//=====================================
     	 if (obj == p1){
             p6.setText("-"+p1.getText()+"- was clicked");
             inPanel.setBackground(Color.blue);
             p1.setBackground(Color.blue);
         }
     	 if (obj == p2){
             p6.setText("-"+p2.getText()+"- was clicked");
             inPanel.setBackground(Color.red);
             p2.setBackground(Color.red);
         }
     	 if (obj == p3){
             p6.setText("-"+p3.getText()+"- was clicked");
             inPanel.setBackground(Color.green);
         }
     	 if (obj == p4){
             p6.setText("-"+p4.getText()+"- was clicked");
             inPanel.setBackground(Color.yellow);
         }
}
 
}
