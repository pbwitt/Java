
import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;


public class GamePanelSettings extends JPanel implements ActionListener
{
    
    JButton gpsShips, gpsDifficulty, gpsCompIntel;
    String shipsNumber, compIntelType, difficultyLevel;
    String informedShips, informedDifficulty, informedCompIntel;
    IntroJPanel introPanel;

    public GamePanelSettings(IntroJPanel n)
    {
        super();
        setLayout(null);
       // Border thickBorder = new LineBorder(Color.BLACK, 3); 
        
        //informedShips = a;
        //informedDifficulty = b;
        //informedCompIntel = c;
        introPanel = n;
        
        gpsShips = new JButton();
        //gpsShips.setText(shipsNumber);
        //gpsShips.setText(informedShips);
        gpsShips.setText((String) introPanel.ships.getSelectedItem());
        System.out.println(informedShips);
        gpsShips.setBounds(10, 20, 100, 50);
        
        gpsDifficulty = new JButton();
        //gpsDifficulty .setText(compIntelType);
        gpsDifficulty .setText("test");
        gpsDifficulty.setBounds(10, 70, 100, 50);
        
        gpsCompIntel = new JButton();
        //gpsCompIntel.setText(difficultyLevel);
        gpsCompIntel.setText("test");
        gpsCompIntel.setBounds(10, 300, 100, 50);
        
        add(gpsShips);
        add(gpsDifficulty);
        add(gpsCompIntel);
        
        
        
        
        
    }

    public void actionPerformed (ActionEvent e)
    {
        Object obj = e.getSource();
        
         
        
        if(obj == introPanel.ships)
        {
            JComboBox ships = (JComboBox) e.getSource();
            shipsNumber = introPanel.ships.getSelectedItem().toString();
            gpsShips.setText(shipsNumber);
            System.out.println(introPanel.ships.getSelectedItem());
            System.out.println("this is working");
            
            //shipsNumber = (String) ships.getSelectedItem();
            
            
            
        }
    }    
    
}
