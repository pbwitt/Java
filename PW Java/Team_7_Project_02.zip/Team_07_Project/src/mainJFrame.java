import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author pbw5003
 */

public class mainJFrame extends JFrame implements ActionListener

{   
 

  JMenuItem exit, play;
  JMenuItem designers, instructions;
  JPanel DesignerJPanel, IntroJPanel;
  
  
public mainJFrame ()
    {
		super ("Team 07");
                
 
                
  	 	ControlPanel mjp = new ControlPanel();
                mjp.setBackground(Color.BLUE);
                getContentPane().add(mjp,"Center");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize (640, 480);
		setVisible(true); 
                
                JMenuBar menuBar = new JMenuBar();
                JMenu menu = new JMenu("Menu");
                JMenu credits = new JMenu("Credits");
                menuBar.add(menu);
                menuBar.add(credits);
    
                play = new JMenuItem("Play");
                exit = new JMenuItem("Exit");
    
                play.addActionListener(this);
                exit.addActionListener(this);
    
                menu.add(play);
                menu.add(exit);
    
                exit.setActionCommand("Exit");
                setJMenuBar(menuBar);
                setVisible(true);
                
                designers = new JMenuItem("Designers");
                instructions = new JMenuItem("Instructions");
                
                credits.add(designers);
                credits.add(instructions);
                
                designers.addActionListener(this);
                instructions.addActionListener(this);

                
                
                
    
    }
        
     public void actionPerformed (ActionEvent e)
    {
        Object obj = e.getSource();
        
        if(obj == exit)
        {
            System.exit(0);
        }
        
        if(obj == designers)
        {
         //IntroJPanel.setVisible(false);
         setLayout(new GridLayout(0,1));
         DesignerJPanel dp1 = new DesignerJPanel(); 
         add(dp1);
         dp1.setVisible(true);
         
         System.out.println("works");
         
         
        }    
    
    }
     
}