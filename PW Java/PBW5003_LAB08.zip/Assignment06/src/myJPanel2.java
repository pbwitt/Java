import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class myJPanel2 extends JPanel 
{
	JButton b2, b3; 
	student st1;
        myJPanel1 mjp1;
        
         
       

	public myJPanel2()
	{
		super();
               
            
		
                st1 = new student();
		setBackground(Color.pink);
		b2 = new JButton("Student Info Here" );
		add(b2);
                b3 = new JButton("You're FIRED!!!!"); 
                add(b3); 
              
                    
                }
//                
//                tft1 = new JTextField(10);
//                tft1.addActionListener(this); 
//		add(tft1); 

//                jb2 = mjp1.b1; 
//                jb2.setText(st1.getInfo()); 
//                jb2.addActionListener(this);	
	}
//        public void actionPerformed(ActionEvent event) 
//    {
//       	 Object obj = event.getSource();       
////=====================================
////     	 if (obj == jb2){
////             b2.setText(st1.getInfo());      
////         }
////         
//         if(obj == tft1){
//        
//             st1.firstName = tft1.getText(); 
//             jb2.setText( st1.firstName); 
//             
             
//         }
//    }
 
  
        
	
