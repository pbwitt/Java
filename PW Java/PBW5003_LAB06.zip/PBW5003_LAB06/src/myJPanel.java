/*
 * /*
 * Paul Witt  Lab O6 
IST240
Septerber 27, 2015
/**
 *
 * @author pbw5003
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class myJPanel extends JPanel
{ 
     
	public myJPanel()
	{
		super();
       {
            myJPanel1 p1 = new myJPanel1();  
	      add(p1, "Left");
             
	}
     }
//-------------------------------------------------------------------
}


