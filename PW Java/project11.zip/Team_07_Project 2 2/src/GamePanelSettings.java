
import javax.swing.JPanel;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;


public class GamePanelSettings extends JPanel
{
    
    JButton gpsShips, gpsDifficulty, gpsCompIntel;
    String shipsNumber, compIntelType, difficultyLevel;
    String informedShips, informedDifficulty, informedCompIntel;
    
    GamePanelSettings()
    {
        informedShips = "";
        informedDifficulty = "";
        informedCompIntel = "";
    }
    public GamePanelSettings(String a, String b, String c)
    {
        super();
        setLayout(null);
        Border thickBorder = new LineBorder(Color.BLACK, 3); 
        
        informedShips = a;
        informedDifficulty = b;
        informedCompIntel = c;
        
        
        gpsShips = new JButton();
        //gpsShips.setText(shipsNumber);
        gpsShips.setText(informedShips);
        System.out.println(informedShips);
        gpsShips.setBounds(10, 20, 100, 50);
        
        gpsDifficulty = new JButton();
        //gpsDifficulty .setText(compIntelType);
        gpsDifficulty .setText("test");
        gpsDifficulty.setBounds(10, 70, 100, 50);
        
        gpsCompIntel = new JButton();
        //gpsCompIntel.setText(difficultyLevel);
        gpsCompIntel.setText("test");
        gpsCompIntel.setBounds(10, 300, 100, 50);
        
        add(gpsShips);
        add(gpsDifficulty);
        add(gpsCompIntel);
        
        
        
        
        
    }

 
    
}
