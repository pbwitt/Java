public class Weather {
    public static void main (String [] arguments) {
        float fah = 86;
        System.out.println (fah + "degress Farhenheit is ...");
        // To convert to Farhenheit into Celsius
        // begin by subtracting 32
        fah = fah - 32;
        // divide the answer by 9
        fah = fah / 9;
        // multiply the answer by 5
        fah = fah * 5;
        System.out.println (fah + " degrees Celsius\n");
        
        float cel = 33;
        System.out.println (cel + "degrees Celius is ...");
        // To convert Celsius to Farhenheit
        // Being by multiplying by 9
        cel = cel * 9;
        // Divide the answer by 5
        cel = cel / 5;
        // Add 32 to the answer
        cel = cel + 32;
        System.out.println(cel + "degrees Farhenheit\n");
    }
}