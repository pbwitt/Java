import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class myJPanel2 extends JPanel
{
	JButton b2;
	public myJPanel2()
	{
		super();
		setBackground(Color.pink);
		b2 = new JButton("whats Up will be shown here" );
		add(b2);
		
		
	}
	
	
}