public class  app4
{
  public static void main(String args[])
  {
    myJFrame4 mjf = new myJFrame4();
  }
}
